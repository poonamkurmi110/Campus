<html>

<head>
    <style>
        a:link {
            color: blue;
        }

        a:visited {
            color: #00008b;
        }

        a:hover {
            color: white;
        }

        a:active {
            color: #008080;
        }
    </style>
</head>

<body style="margin:0px;padding:0px">
    <div style="height:8%;text-align:right;background-color:C8CABD;border-color:#080808">
        <table align="right" height="100%" width="30%" cellspacing="8">
            <tr style="text-align:bottom">
                <td>
                    <h2><a href="companylogin.php" style="text-decoration:none;">Login</a></h2>
                </td>
                <td>
                    <h2>
                        <a href="companyregistration.php" style="text-decoration:none;">Registration</a></h2>
                </td>
            </tr>
        </table>
    </div>
</body>
</style>
</head>

</html>