<?php
session_start();
?>
<html>

<head>
    <title>Welcome Page</title>
</head>

<body style="margin:0px;padding:0px">
    <div style="height:8%;width:100%;background-color:#2B547E;padding-top:100px;padding-left:500px;font-size:30px;color:white">Welcome Admin</div>
    <form method="POST" action="">
        <table style="height:92%;width:100%">
            <tr>
                <td style="width:20%;background-color:C8CABD">
                    <font size="5">
                        <center>
                            <a href="vjobadmin.php" style="text-decoration:none">View Jobseeker Detail</a></br></br>
                            <a href="vcomadmin.php" style="text-decoration:none">View Company Detail</a></br></br>
                            <a href="logoutadmin.php" style="text-decoration:none">LogOut</a></br></br>
                        </center>
                    </font>
                </td>
                <td><img src="img/adminback.jpg" style="height:70%;width:100%">
                </td>
            </tr>
        </table>
    </form>
    </div>
</body>

</html>