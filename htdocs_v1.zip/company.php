<html>
<head>
<title>Student login</title>
<style>
.tb{
margin-left:70px;
}

</style>
</head>
<body style="margin:0px;padding:0px" >
<?php
include("headercompany.php");
?>
<div style="height:92%;width:100%;background-image:url('img/bg88.jpg');background-size:cover;">
<table align="center" class="tb" height="60%" valign="center">
<tr>
<td><font face="Arial Rounded MT" size="12"><b>
POST JOBS</b></font></br></BR>
<font size="40" face="Arial Rounded MT" color="#330066"><b>F</b></font>
<font size="35" face="Arial Rounded MT" color="#330066"><b>IND YOUR NEXT</b></font>
</br><h1><font face="Arial Rounded MT" size="25"><b>EMPLOYEES</b></font></h1>
</td></tr>
</table>
</div>

</body>
</html>
